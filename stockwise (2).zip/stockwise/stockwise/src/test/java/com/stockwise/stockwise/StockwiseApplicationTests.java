package com.stockwise.stockwise;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;

import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import com.stockwise.stockwise.model.MovementType;
import com.stockwise.stockwise.service.InventoryService;
import com.stockwise.stockwise.web.ApiModels.ProductRequest;
import com.stockwise.stockwise.web.ApiModels.StockRequest;

@SpringBootTest(properties = {
		"spring.datasource.url=jdbc:h2:mem:stockwise-test;MODE=MySQL;DB_CLOSE_DELAY=-1",
		"spring.datasource.username=sa",
		"spring.datasource.password=",
		"spring.datasource.driver-class-name=org.h2.Driver",
		"spring.jpa.database-platform=org.hibernate.dialect.H2Dialect"
})
@AutoConfigureMockMvc
@Transactional
class StockwiseApplicationTests {
	private final InventoryService inventory;
	private final MockMvc mockMvc;

	@Autowired
	StockwiseApplicationTests(InventoryService inventory, MockMvc mockMvc) {
		this.inventory = inventory;
		this.mockMvc = mockMvc;
	}

	@Test
	void contextLoads() {
	}

	@Test
	void stockMovementsUpdateQuantityAndRejectOverselling() {
		var product = inventory.createProduct(new ProductRequest(
				"TEA-001", "Green tea", "Beverages", 5, 5, new BigDecimal("12.50"), null));

		assertTrue(product.lowStock());
		inventory.recordMovement(product.id(), new StockRequest(MovementType.STOCK_OUT, 2, "Customer order"));

		var afterSale = inventory.listProducts(null).getFirst();
		assertEquals(3, afterSale.quantity());
		assertTrue(afterSale.lowStock());
		assertEquals(2, inventory.listMovements().size());

		assertThrows(IllegalArgumentException.class, () ->
				inventory.recordMovement(product.id(), new StockRequest(MovementType.STOCK_OUT, 4, null)));
		assertEquals(3, inventory.listProducts(null).getFirst().quantity());
	}

	@Test
	void stockInClearsLowStockAlertAndUpdatesInventoryValue() {
		var product = inventory.createProduct(new ProductRequest(
				"BEAN-002", "Coffee beans", "Pantry", 2, 4, new BigDecimal("100.00"), null));

		var result = inventory.recordMovement(product.id(), new StockRequest(MovementType.STOCK_IN, 5, null));
		var dashboard = inventory.dashboard();

		assertEquals(7, result.quantity());
		assertFalse(result.lowStock());
		assertEquals(7, dashboard.totalUnits());
		assertEquals(new BigDecimal("700.00"), dashboard.inventoryValue());
		assertEquals(0, dashboard.lowStockCount());
	}

	@Test
	void dashboardAndStaticWorkspaceAreServed() throws Exception {
		mockMvc.perform(get("/index.html"))
				.andExpect(status().isOk())
				.andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML))
				.andExpect(content().string(org.hamcrest.Matchers.containsString("Stockwise")));

		mockMvc.perform(get("/api/dashboard"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.productCount").value(0))
				.andExpect(jsonPath("$.totalUnits").value(0))
				.andExpect(jsonPath("$.lowStockCount").value(0));
	}

	@Test
	void productsCanBeCreatedAndRetrievedThroughRestApi() throws Exception {
		mockMvc.perform(post("/api/products")
				.contentType(MediaType.APPLICATION_JSON)
				.content("""
						{
							"sku": "TEA-001",
							"name": "Green tea",
							"category": "Beverages",
							"quantity": 12,
							"reorderLevel": 5,
							"unitPrice": 12.50,
							"supplierId": null
						}
						"""))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.sku").value("TEA-001"))
				.andExpect(jsonPath("$.quantity").value(12));

		mockMvc.perform(get("/api/products"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].name").value("Green tea"))
				.andExpect(jsonPath("$[0].unitPrice").value(12.50));

		mockMvc.perform(get("/api/dashboard"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.productCount").value(1))
				.andExpect(jsonPath("$.totalUnits").value(12));
	}

	@Test
	void invalidAndMalformedRequestsReturnReadableErrors() throws Exception {
		mockMvc.perform(post("/api/products")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"sku\":\"\",\"name\":\"\",\"unitPrice\":-1}"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.error").isNotEmpty());

		mockMvc.perform(post("/api/products")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{invalid-json"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.error").value("Request body is missing or contains invalid JSON."));
	}
}
