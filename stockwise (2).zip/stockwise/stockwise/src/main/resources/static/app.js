const currency = new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	maximumFractionDigits: 2
});
const number = new Intl.NumberFormat("en-IN");
const state = { products: [], suppliers: [], movements: [], toastTimer: null };

const byId = (id) => document.getElementById(id);
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({
	"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
})[character]);

async function api(path, options = {}) {
	const response = await fetch(`/api${path}`, {
		...options,
		headers: { "Content-Type": "application/json", ...options.headers }
	});
	if (response.status === 204) return null;
	const contentType = response.headers.get("content-type") || "";
	const body = contentType.includes("application/json") ? await response.json() : null;
	if (!response.ok) throw new Error(body?.error || `Request failed (${response.status}).`);
	return body;
}

function showToast(message, success = false) {
	const toast = byId("toast");
	toast.textContent = message;
	toast.className = `toast visible${success ? " success" : ""}`;
	clearTimeout(state.toastTimer);
	state.toastTimer = setTimeout(() => toast.classList.remove("visible"), 3500);
}

function formatDate(value) {
	if (!value) return "—";
	return new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeStyle: "short" })
		.format(new Date(value));
}

function movementMarkup(movement) {
	const inbound = movement.type === "STOCK_IN";
	return `<div class="activity-row">
		<span class="movement-mark ${inbound ? "in" : "out"}">${inbound ? "↓" : "↑"}</span>
		<span class="activity-copy"><strong>${escapeHtml(movement.productName)}</strong><small>${escapeHtml(movement.note || (inbound ? "Stock received" : "Stock issued"))} · ${escapeHtml(formatDate(movement.createdAt))}</small></span>
		<span class="movement-amount ${inbound ? "in" : "out"}">${inbound ? "+" : "−"}${number.format(movement.quantity)}</span>
	</div>`;
}

function renderDashboard(dashboard) {
	byId("stat-products").textContent = number.format(dashboard.productCount);
	byId("stat-units").textContent = number.format(dashboard.totalUnits);
	byId("stat-low").textContent = number.format(dashboard.lowStockCount);
	byId("stat-value").textContent = currency.format(dashboard.inventoryValue);

	const lowStockList = byId("low-stock-list");
	lowStockList.innerHTML = dashboard.lowStockProducts.length
		? dashboard.lowStockProducts.slice(0, 5).map((product) => {
			const ratio = product.reorderLevel > 0
				? Math.min(100, Math.round(product.quantity / product.reorderLevel * 100))
				: 0;
			return `<div class="low-stock-row">
				<span class="product-title">${escapeHtml(product.name)}<small class="product-sku">${escapeHtml(product.sku)}</small></span>
				<span class="stock-track" aria-label="${number.format(product.quantity)} in stock"><span style="width:${ratio}%"></span></span>
				<span class="stock-count"><b>${number.format(product.quantity)}</b> left</span>
			</div>`;
		}).join("")
		: '<div class="empty-state">Everything is looking healthy. No low-stock alerts.</div>';
	byId("recent-activity").innerHTML = dashboard.recentMovements.length
		? dashboard.recentMovements.map(movementMarkup).join("")
		: '<div class="empty-state">Stock movements will show up here.</div>';
}

function renderProducts(products) {
	state.products = products;
	byId("product-count").textContent = number.format(products.length);
	byId("products-table").innerHTML = products.length
		? products.map((product) => `<tr>
			<td><span class="product-title">${escapeHtml(product.name)}</span></td>
			<td>${escapeHtml(product.sku)}</td>
			<td>${escapeHtml(product.category || "—")}</td>
			<td>${escapeHtml(product.supplierName || "—")}</td>
			<td><span class="status-pill${product.lowStock ? " low" : ""}">${number.format(product.quantity)}${product.lowStock ? " · Low" : " · In stock"}</span></td>
			<td>${currency.format(product.unitPrice)}</td>
			<td><div class="row-actions">
				<button class="table-action" data-action="stock" data-id="${product.id}" title="Record stock movement">± Stock</button>
				<button class="table-action" data-action="edit-product" data-id="${product.id}" title="Edit product">Edit</button>
				<button class="table-action danger" data-action="delete-product" data-id="${product.id}" title="Delete product">Delete</button>
			</div></td>
		</tr>`).join("")
		: '<tr><td colspan="7" class="empty-state">No products yet. Add your first product to get started.</td></tr>';
}

function renderSuppliers(suppliers) {
	state.suppliers = suppliers;
	byId("supplier-grid").innerHTML = suppliers.length
		? suppliers.map((supplier) => {
			const initials = supplier.name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
			return `<article class="supplier-card">
				<div class="supplier-card-top"><span class="supplier-avatar">${escapeHtml(initials)}</span><div class="row-actions">
					<button class="table-action" data-action="edit-supplier" data-id="${supplier.id}">Edit</button>
					<button class="table-action danger" data-action="delete-supplier" data-id="${supplier.id}">Delete</button>
				</div></div>
				<h2>${escapeHtml(supplier.name)}</h2><p>${escapeHtml(supplier.contactName || "Supplier partner")}</p>
				${supplier.email ? `<div class="supplier-detail">${escapeHtml(supplier.email)}</div>` : ""}
				${supplier.phone ? `<div class="supplier-detail">${escapeHtml(supplier.phone)}</div>` : ""}
				${supplier.address ? `<div class="supplier-detail">${escapeHtml(supplier.address)}</div>` : ""}
			</article>`;
		}).join("")
		: '<div class="panel empty-state">No suppliers added yet. Keep your supply network in one place.</div>';
	refreshSelects();
}

function renderMovements(movements) {
	state.movements = movements;
	byId("movement-count").textContent = number.format(movements.length);
	byId("movements-table").innerHTML = movements.length
		? movements.map((movement) => `<tr>
			<td><span class="product-title">${escapeHtml(movement.productName)}<small class="product-sku">${escapeHtml(movement.sku)}</small></span></td>
			<td><span class="status-pill${movement.type === "STOCK_OUT" ? " low" : ""}">${movement.type === "STOCK_IN" ? "Stock in" : "Stock out"}</span></td>
			<td>${number.format(movement.quantity)}</td><td>${number.format(movement.quantityBefore)}</td><td>${number.format(movement.quantityAfter)}</td>
			<td>${escapeHtml(movement.note || "—")}</td><td>${escapeHtml(formatDate(movement.createdAt))}</td>
		</tr>`).join("")
		: '<tr><td colspan="7" class="empty-state">No stock movements have been recorded.</td></tr>';
}

function refreshSelects() {
	document.querySelectorAll('select[name="supplierId"]').forEach((select) => {
		const selected = select.value;
		select.innerHTML = '<option value="">No supplier</option>' + state.suppliers.map((supplier) =>
			`<option value="${supplier.id}">${escapeHtml(supplier.name)}</option>`).join("");
		select.value = selected;
	});
	const productSelect = document.querySelector('#movement-form select[name="productId"]');
	const selectedProduct = productSelect.value;
	productSelect.innerHTML = state.products.map((product) =>
		`<option value="${product.id}">${escapeHtml(product.name)} · ${number.format(product.quantity)} in stock</option>`).join("");
	productSelect.value = selectedProduct;
}

async function loadData() {
	const results = await Promise.allSettled([
		api("/dashboard"), api("/products"), api("/suppliers"), api("/movements")
	]);
	const renderers = [renderDashboard, renderProducts, renderSuppliers, renderMovements];
	let firstError = null;
	results.forEach((result, index) => {
		if (result.status === "fulfilled") {
			renderers[index](result.value);
		} else if (!firstError) {
			firstError = result.reason;
		}
	});
	if (firstError) showToast(firstError.message || "Some inventory data could not be loaded.");
}

function openDialog(id, record = null) {
	const dialog = byId(id);
	const form = dialog.querySelector("form");
	form.reset();
	if (id === "product-dialog") {
		form.elements.id.value = record?.id || "";
		form.elements.name.value = record?.name || "";
		form.elements.sku.value = record?.sku || "";
		form.elements.category.value = record?.category || "";
		form.elements.quantity.value = record?.quantity ?? 0;
		form.elements.reorderLevel.value = record?.reorderLevel ?? 5;
		form.elements.unitPrice.value = record?.unitPrice ?? "0.00";
		form.elements.supplierId.value = record?.supplierId || "";
		byId("product-dialog-title").textContent = record ? "Edit product" : "Add a product";
	} else if (id === "supplier-dialog") {
		form.elements.id.value = record?.id || "";
		form.elements.name.value = record?.name || "";
		form.elements.contactName.value = record?.contactName || "";
		form.elements.email.value = record?.email || "";
		form.elements.phone.value = record?.phone || "";
		form.elements.address.value = record?.address || "";
		byId("supplier-dialog-title").textContent = record ? "Edit supplier" : "Add a supplier";
	} else if (id === "movement-dialog") {
		form.elements.productId.value = record?.id || state.products[0]?.id || "";
		form.elements.type.value = "STOCK_IN";
	}
	dialog.showModal();
}

function formData(form, fields) {
	return Object.fromEntries(fields.map((field) => {
		const value = form.elements[field].value.trim();
		if (field === "quantity" || field === "reorderLevel") return [field, Number(value)];
		if (field === "unitPrice") return [field, Number(value)];
		if (field === "supplierId") return [field, value ? Number(value) : null];
		return [field, value || null];
	}));
}

document.querySelectorAll("[data-page]").forEach((link) => {
	link.addEventListener("click", (event) => {
		event.preventDefault();
		const page = link.dataset.page;
		document.querySelectorAll(".page-section").forEach((section) => section.classList.remove("active"));
		document.querySelectorAll(".nav-link").forEach((navLink) => navLink.classList.toggle("active", navLink.dataset.page === page));
		byId(`page-${page}`).classList.add("active");
		byId("breadcrumb-current").textContent = page === "history" ? "Stock history" : page[0].toUpperCase() + page.slice(1);
		history.replaceState(null, "", `#${page}`);
	});
});

document.querySelectorAll("[data-open]").forEach((button) => {
	button.addEventListener("click", () => openDialog(button.dataset.open));
});
document.querySelectorAll("[data-close]").forEach((button) => {
	button.addEventListener("click", () => button.closest("dialog").close());
});
document.querySelectorAll("dialog").forEach((dialog) => {
	dialog.addEventListener("click", (event) => {
		if (event.target === dialog) dialog.close();
	});
});
byId("refresh-button").addEventListener("click", loadData);

byId("product-search").addEventListener("input", async (event) => {
	try {
		const products = await api(`/products?search=${encodeURIComponent(event.target.value)}`);
		renderProducts(products);
	} catch (error) {
		showToast(error.message);
	}
});

byId("product-form").addEventListener("submit", async (event) => {
	event.preventDefault();
	const form = event.currentTarget;
	const id = form.elements.id.value;
	const payload = formData(form, ["sku", "name", "category", "quantity", "reorderLevel", "unitPrice", "supplierId"]);
	try {
		await api(id ? `/products/${id}` : "/products", {
			method: id ? "PUT" : "POST", body: JSON.stringify(payload)
		});
		byId("product-dialog").close();
		showToast(id ? "Product updated." : "Product added to your inventory.", true);
		await loadData();
	} catch (error) {
		showToast(error.message);
	}
});

byId("supplier-form").addEventListener("submit", async (event) => {
	event.preventDefault();
	const form = event.currentTarget;
	const id = form.elements.id.value;
	const payload = formData(form, ["name", "contactName", "email", "phone", "address"]);
	try {
		await api(id ? `/suppliers/${id}` : "/suppliers", {
			method: id ? "PUT" : "POST", body: JSON.stringify(payload)
		});
		byId("supplier-dialog").close();
		showToast(id ? "Supplier updated." : "Supplier added.", true);
		await loadData();
	} catch (error) {
		showToast(error.message);
	}
});

byId("movement-form").addEventListener("submit", async (event) => {
	event.preventDefault();
	const form = event.currentTarget;
	const productId = form.elements.productId.value;
	const payload = {
		type: form.elements.type.value,
		quantity: Number(form.elements.quantity.value),
		note: form.elements.note.value.trim() || null
	};
	try {
		await api(`/products/${productId}/movements`, { method: "POST", body: JSON.stringify(payload) });
		byId("movement-dialog").close();
		showToast("Stock movement recorded.", true);
		await loadData();
	} catch (error) {
		showToast(error.message);
	}
});

document.addEventListener("click", async (event) => {
	const button = event.target.closest("[data-action]");
	if (!button) return;
	const id = Number(button.dataset.id);
	const action = button.dataset.action;
	if (action === "edit-product") {
		const product = state.products.find((item) => item.id === id);
		if (product) openDialog("product-dialog", product);
		return;
	}
	if (action === "edit-supplier") {
		const supplier = state.suppliers.find((item) => item.id === id);
		if (supplier) openDialog("supplier-dialog", supplier);
		return;
	}
	if (action === "stock") {
		const product = state.products.find((item) => item.id === id);
		if (product) openDialog("movement-dialog", product);
		return;
	}
	const label = action === "delete-product" ? "product" : "supplier";
	if (!window.confirm(`Delete this ${label}? This action cannot be undone.`)) return;
	try {
		await api(`/${label === "product" ? "products" : "suppliers"}/${id}`, { method: "DELETE" });
		showToast(`${label[0].toUpperCase() + label.slice(1)} deleted.`, true);
		await loadData();
	} catch (error) {
		showToast(error.message);
	}
});

const today = new Intl.DateTimeFormat("en-IN", { weekday: "long", day: "numeric", month: "long" }).format(new Date());
byId("today-label").textContent = today.toUpperCase();
const initialPage = window.location.hash.slice(1);
if (["overview", "inventory", "suppliers", "history"].includes(initialPage)) {
	document.querySelector(`[data-page="${initialPage}"]`).click();
}
loadData();
