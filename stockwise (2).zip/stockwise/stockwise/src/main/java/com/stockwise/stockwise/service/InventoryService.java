package com.stockwise.stockwise.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.stockwise.stockwise.model.MovementType;
import com.stockwise.stockwise.model.Product;
import com.stockwise.stockwise.model.StockMovement;
import com.stockwise.stockwise.model.Supplier;
import com.stockwise.stockwise.repository.ProductRepository;
import com.stockwise.stockwise.repository.StockMovementRepository;
import com.stockwise.stockwise.repository.SupplierRepository;
import com.stockwise.stockwise.web.ApiModels.DashboardResponse;
import com.stockwise.stockwise.web.ApiModels.MovementResponse;
import com.stockwise.stockwise.web.ApiModels.ProductRequest;
import com.stockwise.stockwise.web.ApiModels.ProductResponse;
import com.stockwise.stockwise.web.ApiModels.StockRequest;
import com.stockwise.stockwise.web.ApiModels.SupplierRequest;
import com.stockwise.stockwise.web.ApiModels.SupplierResponse;

@Service
public class InventoryService {
	private final ProductRepository products;
	private final SupplierRepository suppliers;
	private final StockMovementRepository movements;

	public InventoryService(ProductRepository products, SupplierRepository suppliers,
			StockMovementRepository movements) {
		this.products = products;
		this.suppliers = suppliers;
		this.movements = movements;
	}

	@Transactional(readOnly = true)
	public List<ProductResponse> listProducts(String search) {
		List<Product> found = search == null || search.isBlank()
				? products.findAllByOrderByNameAsc()
				: products.findByNameContainingIgnoreCaseOrSkuContainingIgnoreCaseOrderByNameAsc(
						search.trim(), search.trim());
		return found.stream().map(this::toProductResponse).toList();
	}

	@Transactional
	public ProductResponse createProduct(ProductRequest request) {
		Product product = new Product(
				request.sku().trim().toUpperCase(Locale.ROOT),
				request.name().trim(),
				clean(request.category()),
				request.quantity(),
				request.reorderLevel(),
				request.unitPrice(),
				findSupplier(request.supplierId()));
		products.save(product);
		if (request.quantity() > 0) {
			movements.save(new StockMovement(product, MovementType.STOCK_IN, request.quantity(),
					0, request.quantity(), "Opening stock"));
		}
		return toProductResponse(product);
	}

	@Transactional
	public ProductResponse updateProduct(Long id, ProductRequest request) {
		Product product = findProduct(id);
		if (product.getQuantity() != request.quantity()) {
			throw new IllegalArgumentException("Use stock-in or stock-out to change product quantity.");
		}
		product.setSku(request.sku().trim().toUpperCase(Locale.ROOT));
		product.setName(request.name().trim());
		product.setCategory(clean(request.category()));
		product.setReorderLevel(request.reorderLevel());
		product.setUnitPrice(request.unitPrice());
		product.setSupplier(findSupplier(request.supplierId()));
		return toProductResponse(products.save(product));
	}

	@Transactional
	public void deleteProduct(Long id) {
		Product product = findProduct(id);
		if (movements.existsByProductId(id)) {
			throw new IllegalStateException("Products with stock history cannot be deleted.");
		}
		products.delete(product);
	}

	@Transactional(readOnly = true)
	public List<SupplierResponse> listSuppliers() {
		return suppliers.findAll().stream().map(this::toSupplierResponse).toList();
	}

	@Transactional
	public SupplierResponse createSupplier(SupplierRequest request) {
		return toSupplierResponse(suppliers.save(new Supplier(
				request.name().trim(), clean(request.contactName()), clean(request.email()),
				clean(request.phone()), clean(request.address()))));
	}

	@Transactional
	public SupplierResponse updateSupplier(Long id, SupplierRequest request) {
		Supplier supplier = findSupplier(id);
		supplier.setName(request.name().trim());
		supplier.setContactName(clean(request.contactName()));
		supplier.setEmail(clean(request.email()));
		supplier.setPhone(clean(request.phone()));
		supplier.setAddress(clean(request.address()));
		return toSupplierResponse(suppliers.save(supplier));
	}

	@Transactional
	public void deleteSupplier(Long id) {
		Supplier supplier = findSupplier(id);
		if (products.existsBySupplierId(id)) {
			throw new IllegalStateException("Remove this supplier from its products before deleting it.");
		}
		suppliers.delete(supplier);
	}

	@Transactional
	public ProductResponse recordMovement(Long productId, StockRequest request) {
		Product product = findProduct(productId);
		int before = product.getQuantity();
		int after = request.type() == MovementType.STOCK_IN
				? Math.addExact(before, request.quantity())
				: before - request.quantity();
		if (after < 0) {
			throw new IllegalArgumentException("Stock-out quantity cannot exceed the available quantity.");
		}
		product.setQuantity(after);
		products.save(product);
		movements.save(new StockMovement(product, request.type(), request.quantity(), before, after,
				clean(request.note())));
		return toProductResponse(product);
	}

	@Transactional(readOnly = true)
	public List<MovementResponse> listMovements() {
		return movements.findTop100ByOrderByCreatedAtDesc().stream().map(this::toMovementResponse).toList();
	}

	@Transactional(readOnly = true)
	public DashboardResponse dashboard() {
		List<Product> allProducts = products.findAll();
		List<ProductResponse> lowStock = allProducts.stream()
				.filter(product -> product.getQuantity() <= product.getReorderLevel())
				.map(this::toProductResponse).toList();
		long totalUnits = allProducts.stream().mapToLong(Product::getQuantity).sum();
		BigDecimal inventoryValue = allProducts.stream()
				.map(product -> product.getUnitPrice().multiply(BigDecimal.valueOf(product.getQuantity())))
				.reduce(BigDecimal.ZERO, BigDecimal::add);
		return new DashboardResponse(allProducts.size(), totalUnits, lowStock.size(), inventoryValue,
				lowStock, movements.findTop100ByOrderByCreatedAtDesc().stream()
						.limit(8).map(this::toMovementResponse).toList());
	}

	private Product findProduct(Long id) {
		return products.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found."));
	}

	private Supplier findSupplier(Long id) {
		if (id == null) {
			return null;
		}
		return suppliers.findById(id).orElseThrow(() -> new ResourceNotFoundException("Supplier not found."));
	}

	private ProductResponse toProductResponse(Product product) {
		Supplier supplier = product.getSupplier();
		return new ProductResponse(product.getId(), product.getSku(), product.getName(), product.getCategory(),
				product.getQuantity(), product.getReorderLevel(), product.getUnitPrice(),
				supplier == null ? null : supplier.getId(),
				supplier == null ? null : supplier.getName(),
				product.getQuantity() <= product.getReorderLevel());
	}

	private SupplierResponse toSupplierResponse(Supplier supplier) {
		return new SupplierResponse(supplier.getId(), supplier.getName(), supplier.getContactName(),
				supplier.getEmail(), supplier.getPhone(), supplier.getAddress());
	}

	private MovementResponse toMovementResponse(StockMovement movement) {
		Product product = movement.getProduct();
		return new MovementResponse(movement.getId(), product.getId(), product.getName(), product.getSku(),
				movement.getType(), movement.getQuantity(), movement.getQuantityBefore(),
				movement.getQuantityAfter(), movement.getNote(), movement.getCreatedAt());
	}

	private String clean(String value) {
		return value == null || value.isBlank() ? null : value.trim();
	}
}
