package com.stockwise.stockwise.web;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.stockwise.stockwise.service.ResourceNotFoundException;
import com.stockwise.stockwise.web.ApiModels.ErrorResponse;

import jakarta.validation.ConstraintViolationException;

@RestControllerAdvice
public class ApiExceptionHandler {
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ErrorResponse> notFound(ResourceNotFoundException exception) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ErrorResponse(exception.getMessage()));
	}

	@ExceptionHandler({
			IllegalArgumentException.class,
			MethodArgumentNotValidException.class,
			ConstraintViolationException.class,
			HttpMessageNotReadableException.class
	})
	public ResponseEntity<ErrorResponse> badRequest(Exception exception) {
		String message = exception instanceof MethodArgumentNotValidException validationException
				? validationException.getBindingResult().getFieldErrors().stream()
						.map(error -> error.getField() + ": " + error.getDefaultMessage())
						.findFirst().orElse("Request validation failed.")
				: exception instanceof ConstraintViolationException violationException
						? violationException.getConstraintViolations().stream()
								.map(violation -> violation.getPropertyPath() + ": " + violation.getMessage())
								.findFirst().orElse("Request validation failed.")
						: exception instanceof HttpMessageNotReadableException
								? "Request body is missing or contains invalid JSON."
								: exception.getMessage();
		return ResponseEntity.badRequest().body(new ErrorResponse(message));
	}

	@ExceptionHandler({ IllegalStateException.class, DataIntegrityViolationException.class })
	public ResponseEntity<ErrorResponse> conflict(Exception exception) {
		String message = exception instanceof DataIntegrityViolationException
				? "The request conflicts with existing inventory data."
				: exception.getMessage();
		return ResponseEntity.status(HttpStatus.CONFLICT).body(new ErrorResponse(message));
	}

	@ExceptionHandler(ArithmeticException.class)
	public ResponseEntity<ErrorResponse> arithmetic(ArithmeticException exception) {
		return ResponseEntity.badRequest().body(new ErrorResponse("The requested stock quantity is too large."));
	}
}
