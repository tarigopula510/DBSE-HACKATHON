package com.stockwise.stockwise.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stockwise.stockwise.model.Supplier;

public interface SupplierRepository extends JpaRepository<Supplier, Long> {
}
