package com.stockwise.stockwise.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "stock_movements")
public class StockMovement {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "product_id", nullable = false)
	private Product product;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private MovementType type;

	@Column(nullable = false)
	private int quantity;

	@Column(nullable = false)
	private int quantityBefore;

	@Column(nullable = false)
	private int quantityAfter;

	@Column(length = 500)
	private String note;

	@Column(nullable = false)
	private LocalDateTime createdAt;

	protected StockMovement() {
	}

	public StockMovement(Product product, MovementType type, int quantity, int quantityBefore, int quantityAfter,
			String note) {
		this.product = product;
		this.type = type;
		this.quantity = quantity;
		this.quantityBefore = quantityBefore;
		this.quantityAfter = quantityAfter;
		this.note = note;
	}

	@PrePersist
	void setCreatedAt() {
		if (createdAt == null) {
			createdAt = LocalDateTime.now();
		}
	}

	public Long getId() {
		return id;
	}

	public Product getProduct() {
		return product;
	}

	public MovementType getType() {
		return type;
	}

	public int getQuantity() {
		return quantity;
	}

	public int getQuantityBefore() {
		return quantityBefore;
	}

	public int getQuantityAfter() {
		return quantityAfter;
	}

	public String getNote() {
		return note;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
}
