package com.stockwise.stockwise.web;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.stockwise.stockwise.service.InventoryService;
import com.stockwise.stockwise.web.ApiModels.DashboardResponse;
import com.stockwise.stockwise.web.ApiModels.MovementResponse;
import com.stockwise.stockwise.web.ApiModels.ProductRequest;
import com.stockwise.stockwise.web.ApiModels.ProductResponse;
import com.stockwise.stockwise.web.ApiModels.StockRequest;
import com.stockwise.stockwise.web.ApiModels.SupplierRequest;
import com.stockwise.stockwise.web.ApiModels.SupplierResponse;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class InventoryController {
	private final InventoryService inventory;

	public InventoryController(InventoryService inventory) {
		this.inventory = inventory;
	}

	@GetMapping("/dashboard")
	public DashboardResponse dashboard() {
		return inventory.dashboard();
	}

	@GetMapping("/products")
	public List<ProductResponse> products(@RequestParam(required = false) String search) {
		return inventory.listProducts(search);
	}

	@PostMapping("/products")
	@ResponseStatus(HttpStatus.CREATED)
	public ProductResponse createProduct(@Valid @RequestBody ProductRequest request) {
		return inventory.createProduct(request);
	}

	@PutMapping("/products/{id}")
	public ProductResponse updateProduct(@PathVariable Long id, @Valid @RequestBody ProductRequest request) {
		return inventory.updateProduct(id, request);
	}

	@DeleteMapping("/products/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteProduct(@PathVariable Long id) {
		inventory.deleteProduct(id);
	}

	@PostMapping("/products/{id}/movements")
	public ProductResponse recordMovement(@PathVariable Long id, @Valid @RequestBody StockRequest request) {
		return inventory.recordMovement(id, request);
	}

	@GetMapping("/movements")
	public List<MovementResponse> movements() {
		return inventory.listMovements();
	}

	@GetMapping("/suppliers")
	public List<SupplierResponse> suppliers() {
		return inventory.listSuppliers();
	}

	@PostMapping("/suppliers")
	@ResponseStatus(HttpStatus.CREATED)
	public SupplierResponse createSupplier(@Valid @RequestBody SupplierRequest request) {
		return inventory.createSupplier(request);
	}

	@PutMapping("/suppliers/{id}")
	public SupplierResponse updateSupplier(@PathVariable Long id, @Valid @RequestBody SupplierRequest request) {
		return inventory.updateSupplier(id, request);
	}

	@DeleteMapping("/suppliers/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteSupplier(@PathVariable Long id) {
		inventory.deleteSupplier(id);
	}
}
