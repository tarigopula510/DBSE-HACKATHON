package com.stockwise.stockwise.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stockwise.stockwise.model.StockMovement;

public interface StockMovementRepository extends JpaRepository<StockMovement, Long> {
	List<StockMovement> findTop100ByOrderByCreatedAtDesc();

	boolean existsByProductId(Long productId);
}
