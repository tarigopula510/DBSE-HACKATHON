package com.stockwise.stockwise.web;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.stockwise.stockwise.model.MovementType;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

public final class ApiModels {
	private ApiModels() {
	}

	public record ProductRequest(
			@NotBlank String sku,
			@NotBlank String name,
			String category,
			@PositiveOrZero int quantity,
			@PositiveOrZero int reorderLevel,
			@NotNull @DecimalMin("0.0") BigDecimal unitPrice,
			Long supplierId) {
	}

	public record SupplierRequest(
			@NotBlank String name,
			String contactName,
			@Email String email,
			String phone,
			String address) {
	}

	public record StockRequest(
			@NotNull MovementType type,
			@Positive int quantity,
			String note) {
	}

	public record ProductResponse(
			Long id,
			String sku,
			String name,
			String category,
			int quantity,
			int reorderLevel,
			BigDecimal unitPrice,
			Long supplierId,
			String supplierName,
			boolean lowStock) {
	}

	public record SupplierResponse(
			Long id,
			String name,
			String contactName,
			String email,
			String phone,
			String address) {
	}

	public record MovementResponse(
			Long id,
			Long productId,
			String productName,
			String sku,
			MovementType type,
			int quantity,
			int quantityBefore,
			int quantityAfter,
			String note,
			LocalDateTime createdAt) {
	}

	public record DashboardResponse(
			long productCount,
			long totalUnits,
			long lowStockCount,
			BigDecimal inventoryValue,
			java.util.List<ProductResponse> lowStockProducts,
			java.util.List<MovementResponse> recentMovements) {
	}

	public record ErrorResponse(String error) {
	}
}
