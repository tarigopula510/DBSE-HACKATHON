package com.stockwise.stockwise.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stockwise.stockwise.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
	List<Product> findAllByOrderByNameAsc();

	List<Product> findByNameContainingIgnoreCaseOrSkuContainingIgnoreCaseOrderByNameAsc(String name, String sku);

	List<Product> findByQuantityLessThanEqualOrderByQuantityAscReorderLevelAsc(int reorderLevel);

	boolean existsBySupplierId(Long supplierId);
}
