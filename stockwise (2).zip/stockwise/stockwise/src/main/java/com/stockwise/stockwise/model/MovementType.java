package com.stockwise.stockwise.model;

public enum MovementType {
	STOCK_IN,
	STOCK_OUT
}
