# Stockwise

Stockwise is an inventory management MVP based on challenge 12, “Smart Inventory
Management,” in the CodeSpark Hackathon 2026 problem statement compendium.

## Features

- Dashboard with product count, units on hand, inventory value, and low-stock alerts.
- Product and supplier management, with supplier-to-product relationships.
- Stock-in and stock-out transactions with a chronological audit history.
- Validation prevents negative inventory and preserves products with movement history.
- Responsive web interface served by Spring Boot at `/`.

## Run locally

Requirements: Java 21 and Maven (or the included Maven wrapper). The app runs
out of the box with a local, file-backed H2 database; its data is stored in
`./data/stockwise`.

1. From the project directory, run:

   ```powershell
   .\mvnw.cmd spring-boot:run
   ```

2. Open [http://localhost:8080](http://localhost:8080).

To use MySQL instead, set `SPRING_DATASOURCE_URL` (for example
`jdbc:mysql://localhost:3306/stockwise`), `SPRING_DATASOURCE_USERNAME`, and
`SPRING_DATASOURCE_PASSWORD` in the environment before starting the app. The
application creates and updates its tables through Hibernate. Tests use an
in-memory H2 database:

```powershell
.\mvnw.cmd test
```

## REST API

- `GET /api/dashboard`
- `GET /api/products?search=...`, `POST /api/products`
- `PUT /api/products/{id}`, `DELETE /api/products/{id}`
- `POST /api/products/{id}/movements` (`STOCK_IN` or `STOCK_OUT`)
- `GET /api/movements` (most recent 100)
- `GET /api/suppliers`, `POST /api/suppliers`
- `PUT /api/suppliers/{id}`, `DELETE /api/suppliers/{id}`

Requests that violate validation or stock rules return a JSON error response.
